# Grass Bot Newer Version Community Node 1.25x, Multiple Accounts
Automate Grass Node mining with this Python based script for VPS, managing multiple Devices and IP address to ensure 24/7 uptime and maximize earnings. Perfect for those seeking a seamless and efficient way to handle WebSocket connections through SOCKS5 Protocol.

# Features
* Grass Node Script for Stage 2 and 1.25x boost !!
* Connects to a WebSocket server using SOCKS5 proxies.
* Handles Multiple Get Grass User IDs at once !! Multiple Proxies (1 Proxy ~3000 $GRASS Points per day)
* As Per Stage 1 AIRDROP 1M Grass Points == 45 GRASS tokens roughly (N/A for Bonus Epooch) !!
* Based ON Data USAGE 2 GB PROXY DATA Produces 1M Points Means; 6$ Spent on proxy Gives ~45 GRASS tokens.
* Handles All kinds of Error such a Dead proxy/ SSL: WRONG_VERSION_NUMBER / invalid length of packed IP address / Empty connect reply / sent 1011 (internal error) keepalive.
* Automatically removes the dead proxy from the File!!

# Get User Id

1. Open the link and log in https://app.getgrass.io/dashboard
2. Press F12 on the page to open the console and enter the code (Ctrl + Shift + i) inspect
3. Write localStorage.getItem('userId') in the console
4. "PRINTED TEXT IS THE USER_ID"


## Requirements

- Invitation link Get Grass Accounts  [https://app.getgrass.io/register/](https://app.getgrass.io/register/?referralCode=P9wETOOuI6cfoZl)
- Python (install Python By - https://www.python.org/downloads/ [windows/mac]) or Ubuntu Server [`sudo apt install python3`]
- VPS Server ! You can get Via AWS free Tier or Google Free tier or any online for just ~ 2-5$ per month
- Proxy Server - Buy Static Residential or IPS Residential Proxies to Earn $GRASS else you will earn 0% on data Centers / Free Cheap proxies (Best proxy providers are)
- For Proxies -  (https://www.webshare.io/?referral_code=soye5s7zh38u) [Buy 1month - any amount of proxies and 250GB (ur-choice)]
- Proxy Server - Buy Only ISP Residential Proxies to Earn $GRASS else you will earn 0% on data Centers

- Now you're going to generate socks5 proxies, and add them to the proxy.txt file.

## SETPS TO RUN THE CODE -

Before running the script, ensure you have Python installed on your machine. Then, install the necessary Python packages using:

1. Download grass script file
2. ``` cd NewGrassBot ```
3. ``` pip install -r requirements.txt ```
4. Replace `User ID` in `main.py` 
5. By default 100 proxies will be taken randomly if you wana change then change here `active_proxies = random.sample(all_proxies, 100)` . Here 100 means 100 proxy will be used at once.
6. Dont Forget to add multiple proxies in the proxy.txt file you can add 1000+ proxy !! Formate # `socks5://username:pass@ip:port`.
7. You can get Multiple Proxy Ip address from Proxies.fo Website !! [use multiple IP ! `1 IP == ~3000 $Grass per Day `.
8. To Run Script `python3 main.py` - Proxy one
9. To Run multiple User ID just copy paste the `main.py` file code and create new python file and repeat the process make sure to create new Folders and add different proxies !!. 


# SOCIALS -

- **Telegram** - [https://t.me/yannaingko2]
